const { test, expect } = require('@playwright/test');

test('LogIn', async ({ page }) => {
  // Navigate to the login page and wait for it to load
  await page.goto('https://order-online-staging.vercel.app/login', { waitUntil: 'domcontentloaded' });
  console.log('Navigated to the login page.');
  await page.waitForTimeout(2000);

  // Wait for email and password fields to be available
  await page.waitForSelector('input[name="email"]', { timeout: 10000 });
  await page.waitForSelector('input[name="password"]', { timeout: 10000 });

  // Login
  await page.locator('input[name="email"]').fill('automationengineer04@gmail.com');
  await page.locator('input[name="password"]').fill('123456789');
  await page.locator('button:has-text("LOGIN")').click();
  console.log('Login button clicked.');

  // Wait for successful login redirection
  await page.waitForURL('https://order-online-staging.vercel.app/', { timeout: 15000 });
  console.log('Logged in successfully.');
  await page.waitForTimeout(2000);

  // Continue the order flow...
});