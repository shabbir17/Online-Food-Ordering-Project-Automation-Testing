const { test, expect, firefox } = require('@playwright/test');

test('Facebook Login in Firefox and save session', async () => {
  // Launch Firefox browser
  const firefoxBrowser = await firefox.launch({
    headless: false, // Set to true for headless mode
  });

  // Create a new browser context to simulate an isolated environment
  const context = await firefoxBrowser.newContext();

  // Check if session exists
  const storageStatePath = 'facebook_state.json';
  try {
    await context.storageState({ path: storageStatePath });
    console.log('Session restored!');
  } catch (error) {
    console.log('No existing session, performing login...');
  }

  // Create a new page
  const page = await context.newPage();
  
  // Go to the login page
  await page.goto('https://order-online-staging.vercel.app/login');
  console.log('Navigated to the login page.');

  await page.waitForTimeout(2000);

  // If no session exists, log in with Facebook
  const [popup] = await Promise.all([
    context.waitForEvent('page'),
    page.click('text=Sign in with Facebook'),
  ]);

  await popup.waitForLoadState('domcontentloaded');
  await popup.waitForSelector('input[name="email"]', { state: 'visible', timeout: 10000 });

  // Fill in Facebook email
  await popup.fill('input[name="email"]', 'automationengineer04@gmail.com');
  console.log('Filled in Facebook email.');

  await popup.fill('input[name="pass"]', 'Shabbir17@');
  console.log('Filled in Facebook password.');

  await popup.click('button[name="login"]');
  console.log('Clicked Facebook Login button.');

  await popup.waitForNavigation();
  
  // Save session for automatic login in the future
  await context.storageState({ path: storageStatePath });
  console.log('Session saved for future use.');

  await expect(page).toHaveURL('https://order-online-staging.vercel.app/');
  console.log('Login successful!');
  await page.waitForTimeout(2000);

  await firefoxBrowser.close();
});
