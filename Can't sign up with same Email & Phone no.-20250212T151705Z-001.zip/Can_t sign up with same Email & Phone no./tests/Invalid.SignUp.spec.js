const { test, expect } = require('@playwright/test');

function generateRandomString() {
  return Math.random().toString(36).substring(2, 15);
}

test('Sign Up Automation', async ({ page }) => {
  // Navigate to the signup page with networkidle to ensure full page load
  await page.goto('https://order-online-staging.vercel.app/signup', { waitUntil: 'networkidle' });
  console.log('Navigated to the signup page.');

  // Generate random email and phone
  const randomEmail = `test_${generateRandomString()}@example.com`;
  const randomPhone = `01${Math.floor(Math.random() * 1000000000)}`;

  // Define input selectors
  const name = 'input[name="name"]';
  const email = 'input[name="email"]';
  const phone = 'input[name="phone"]';
  const password = 'input[name="password"]';
  const passwordConfirmation = 'input[name="passwordConfirmation"]';
  const terms = 'input[type="checkbox"]';
  const submit = page.locator('button[type="submit"]');

  // Ensure all fields are visible before interacting
  await expect(page.locator(name)).toBeVisible();
  await expect(page.locator(email)).toBeVisible();
  await expect(page.locator(phone)).toBeVisible();
  await expect(page.locator(password)).toBeVisible();
  await expect(page.locator(passwordConfirmation)).toBeVisible();

  // Fill out the signup form with random data
  await page.locator(name).fill('Shabbir Ajam');
  await page.locator(email).fill('shabbirajamulubbi@gmail.com');
  await page.locator(phone).fill('01785356925');
  await page.locator(password).fill('Test@12336');
  await page.locator(passwordConfirmation).fill('Test@12336');

  // Agree to privacy policy & terms
  await page.locator(terms).check();

  // Ensure the button is visible before clicking
  await submit.waitFor({ state: 'visible', timeout: 5000 });

  // Click the "SIGN UP" button
  await submit.nth(0).click();
  console.log('Clicked on Sign Up.');

  // Assert successful redirection
  await expect(page).toHaveURL(/order-online-staging\.vercel\.app/);
  console.log('Signup completed successfully.');

  await page.waitForTimeout(2000);
});